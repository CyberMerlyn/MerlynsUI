ContainerFrameCombinedBags:HookScript("OnShow", function(self) RunNextFrame(function() ContainerFrameCombinedBags:SetTitle(UnitName('player', true) .. "'s Inventory") end) end)

local function setBagButtonAlpha(container)
    for _, button in ipairs(container.Items) do
        button:SetAlpha(0.76)
    end
end
setBagButtonAlpha(ContainerFrame1)

local function setBagButtonAlpha(container)
    for _, button in ipairs(container.Items) do
        button:SetAlpha(0.76)
    end
end
setBagButtonAlpha(ContainerFrame2)

local function setBagButtonAlpha(container)
    for _, button in ipairs(container.Items) do
        button:SetAlpha(0.76)
    end
end
setBagButtonAlpha(ContainerFrame3)

local function setBagButtonAlpha(container)
    for _, button in ipairs(container.Items) do
        button:SetAlpha(0.76)
    end
end
setBagButtonAlpha(ContainerFrame4)

local function setBagButtonAlpha(container)
    for _, button in ipairs(container.Items) do
        button:SetAlpha(0.76)
    end
end
setBagButtonAlpha(ContainerFrame5)

local function setBagButtonAlpha(container)
    for _, button in ipairs(container.Items) do
        button:SetAlpha(0.76)
    end
end
setBagButtonAlpha(ContainerFrame6) 