# MerlynsUI

A Magical Mysterious Mystical Minimalistic UI for thos people out there who want to be a wizard like me and want a Clean UI, This UI is designed for open world content and only shows you the essentials you need to play your class and only shows you infomation you absolutely need to see to keep the UI clean...

## How To Use

Type `/MerlynsUI` to toggle it on/off
